import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uncheckuser',
  templateUrl: './uncheckuser.component.html',
  styleUrls: ['./uncheckuser.component.scss']
})
export class UncheckuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
