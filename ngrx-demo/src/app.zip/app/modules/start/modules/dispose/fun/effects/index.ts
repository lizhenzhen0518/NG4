import { NgModule} from '@angular/core';
import { EffectsModule} from '@ngrx/effects';

@NgModule({
  imports: [
    EffectsModule.forFeature([])
  ]
})
export class AppEffectsModule {

}
