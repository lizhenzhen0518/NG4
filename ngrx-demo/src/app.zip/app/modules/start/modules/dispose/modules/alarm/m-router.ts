import { Routes} from '@angular/router';
import { AlarmComponent } from './alarm.component';

export const ROUTE_CONFIG: Routes = [
  {
    path: '',
    component: AlarmComponent
  }
]
