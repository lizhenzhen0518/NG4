import { NgModule } from '@angular/core';
import { QuoteService } from './quote.service';

export {


};

@NgModule({
  providers: [
    QuoteService,

  ]
})
export class ServiceModule {
}
