import { Routes} from '@angular/router';
import { SearchComponent } from './search.component';
export const ROUTE_CONFIG: Routes = [
  {
    path: '',
    component: SearchComponent
  }
];
