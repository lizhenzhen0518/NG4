import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uncheckmsg',
  templateUrl: './uncheckmsg.component.html',
  styleUrls: ['./uncheckmsg.component.scss']
})
export class UncheckmsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
