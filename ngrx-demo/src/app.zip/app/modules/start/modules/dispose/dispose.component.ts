import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dispose',
  templateUrl: './dispose.component.html',
  styleUrls: ['./dispose.component.scss']
})
export class DisposeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
