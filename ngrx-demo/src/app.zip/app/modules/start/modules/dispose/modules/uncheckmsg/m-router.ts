import { Routes} from '@angular/router';
import { UncheckmsgComponent } from './uncheckmsg.component';

export const ROUTE_CONFIG: Routes = [
  {
    path: '',
    component: UncheckmsgComponent
  }
]
