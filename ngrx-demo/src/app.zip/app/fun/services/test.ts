import { Injectable} from '@angular/core';
@Injectable()
export class Test {

  constructor() {}
  getTest(): string {
    return 'testtest';
  }
}
