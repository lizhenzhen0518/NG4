import { Routes} from '@angular/router';
import { HomeComponent } from './home.component';
export const ROUTE_CONFIG: Routes = [
  {
    path: '',
    component: HomeComponent
  }
];
