import { Routes} from '@angular/router';
import { CheckmsgComponent } from './checkmsg.component';

export const ROUTE_CONFIG: Routes = [
  {
    path: '',
    component: CheckmsgComponent
  }
]
