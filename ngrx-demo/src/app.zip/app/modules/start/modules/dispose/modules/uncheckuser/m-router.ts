import { Routes} from '@angular/router';
import { UncheckuserComponent } from './uncheckuser.component';

export const ROUTE_CONFIG: Routes = [
  {
    path: '',
    component: UncheckuserComponent
  }
]
