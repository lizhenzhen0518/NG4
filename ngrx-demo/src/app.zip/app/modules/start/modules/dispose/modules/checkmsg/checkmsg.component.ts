import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkmsg',
  templateUrl: './checkmsg.component.html',
  styleUrls: ['./checkmsg.component.scss']
})
export class CheckmsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
