import { Routes} from '@angular/router';
import { CheckuserComponent } from './checkuser.component';

export const ROUTE_CONFIG: Routes = [
  {
    path: '',
    component: CheckuserComponent
  }
]
