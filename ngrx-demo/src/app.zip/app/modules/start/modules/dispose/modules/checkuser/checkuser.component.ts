import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkuser',
  templateUrl: './checkuser.component.html',
  styleUrls: ['./checkuser.component.scss']
})
export class CheckuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
