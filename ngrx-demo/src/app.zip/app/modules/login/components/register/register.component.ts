import { Component, OnInit } from '@angular/core';
import * as fromRoot from '../../../../fun/reducers';
import { Store} from '@ngrx/store';
import { Project} from '../../../../fun/domain';
import { Observable} from 'rxjs/Observable';
import * as projectActions from '../../../../fun/actions/project.action';
import { FormBuilder, FormGroup, FormControl, Validators, ValidatorFn} from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  position$: Observable<Project[]>;
  form: FormGroup;

  constructor(private store$: Store<fromRoot.State>, private fb: FormBuilder) {
    this.store$.dispatch( new projectActions.LoadProjectsAction({}));

  }

  ngOnInit() {
    this.form = this.fb.group({
      email: ['', [ Validators.email, Validators.required]],
      account : ['', [ Validators.required, Validators.minLength(10), Validators.maxLength(20)]],
      username : ['', Validators.required],
      password : ['', Validators.required],
      repeat: ['', Validators.required],
      position: [],

    }, {
      validator: this.equalRepeatAndPassword('password', 'repeat')
    });
    this.position$ = this.store$.select(fromRoot.getProjects);
    this.position$.subscribe( (val: Project[]) => {
      this.form.controls['position'].setValue(val[0]);
    });
  }
  equalRepeatAndPassword(password: string, repeat: string): ValidatorFn {
    return (group: FormGroup): {[key: string]: any} => {
      const passwordValue = group.get(repeat).value;
      const repeatpasswordValue = group.get(repeat).value;
      if (passwordValue !== repeatpasswordValue ) {
        return {
          notEuqalPassword: '密码不相同'
        };
      } else {
        return null;
      }
    };
  }
  validateUserName(c: FormControl): {[key: string]: any}  {
    return  null;
 }
  onSubmit({value, valid}, event: Event) {
  }

}
